<html>

   <head>
      <title>Upload Form</title>
   </head>

   <body>
     <?php $attributes = array("class" => "cd-form");
     echo form_open_multipart("upload/do_upload", $attributes);?>
         <input type = "file" name = "pic" size = "20" />
         <br /><br />
         <input type = "submit" value = "upload" />
      <?php echo form_close(); ?>

   </body>

</html>
