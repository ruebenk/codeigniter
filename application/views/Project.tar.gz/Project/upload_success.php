<html>

   <head>
      <title>Upload Form</title>
   </head>

   <body>
      <h3>Your file was successfully uploaded!</h3>


      <p><?php echo anchor('index.php/upload', 'Upload Another File!'); ?></p>
   </body>

</html>
