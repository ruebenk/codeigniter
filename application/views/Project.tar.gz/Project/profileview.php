

<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Profile</title>
    
    
    
    
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style2.css">

    
    
    
  </head>

  <body>

    <html>
  <head>
		<link rel="stylesheet" type="text/CSS" href="<?php echo base_url(); ?>assets/css/style2.css" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
	</head>
	<body>
		<div class="portfoliocard">
		<div class="coverphoto"></div>
		<div class="profile_picture">
                <img  width=110px; height=110px; src="<?php echo base_url(); ?>uploads/<?php echo $obj["Id"];?>.jpg">
                
                </div>
		<div class="left_col">
			<div class="followers">
				<a href="followers"><div class="follow_count"><?php echo $obj["followers"];?></div>
				Followers</a><br>
				<a href="#"><div class="follow_count"><?php echo $obj["follows"];?></div>
				Following</a><br>
				<a href="#"><div class="follow_count"><?php echo $obj["interest"];?></div>
				Interests</a>
				<a href="#"><div class="follow_count"><?php echo $obj["ques_posted"];?></div>
				Questions Posted</a>
			</div>
		</div>
		<div class="right_col">
			<h2 class="name"><?php echo $obj["Id"]; echo $obj["Name"];?></h2>

			<ul class="contact_information">
				<li class="mail" id="mail1" ondblclick="myFunction(this)"><?php echo $obj["Email"];?></li><br>
				<li class="phone" id="num1" ondblclick="myFunction1(this)"><?php echo $obj["Mobile"];?></li><br>
				
			</ul>
                       <button class="chngpswd" type="button" onclick="ChngPswd()">Change Password</button> 
		</div>
		</div>
	</body>
</html>
    
        <script src="<?php echo base_url(); ?>assets/js/index.js"></script>

    
    
    
  </body>
</html>
